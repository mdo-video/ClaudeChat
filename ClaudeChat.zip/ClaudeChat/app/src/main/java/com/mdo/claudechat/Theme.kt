package com.mdo.claudechat

import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Palette calda: terracotta come colore principale, azzurro polvere come accento. */
private val BrandDark = darkColorScheme(
    primary = Color(0xFFE8A988),
    onPrimary = Color(0xFF4A2410),
    primaryContainer = Color(0xFF6B3A20),
    onPrimaryContainer = Color(0xFFFFDBC8),
    secondary = Color(0xFFD9C3B8),
    onSecondary = Color(0xFF3A2A22),
    secondaryContainer = Color(0xFF54413A),
    onSecondaryContainer = Color(0xFFF4DED3),
    tertiary = Color(0xFFB9C6E0),
    onTertiary = Color(0xFF22304F),
    tertiaryContainer = Color(0xFF384767),
    onTertiaryContainer = Color(0xFFD6E2FF),
    background = Color(0xFF141110),
    onBackground = Color(0xFFEDE0DA),
    surface = Color(0xFF141110),
    onSurface = Color(0xFFEDE0DA),
    surfaceVariant = Color(0xFF4F4540),
    onSurfaceVariant = Color(0xFFD3C3BC),
    outline = Color(0xFF9C8D86),
    outlineVariant = Color(0xFF4F4540),
    surfaceContainerLowest = Color(0xFF0E0B0A),
    surfaceContainerLow = Color(0xFF1C1816),
    surfaceContainer = Color(0xFF201C1A),
    surfaceContainerHigh = Color(0xFF2B2623),
    surfaceContainerHighest = Color(0xFF36302D),
)

private val base = Typography()

private val ClaudeTypography = base.copy(
    displaySmall = base.displaySmall.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = base.labelLarge.copy(fontWeight = FontWeight.SemiBold),
)

private val ClaudeShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun ClaudeTheme(dynamic: Boolean, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val scheme = if (dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        dynamicDarkColorScheme(context)
    } else {
        BrandDark
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = ClaudeTypography,
        shapes = ClaudeShapes,
        content = content,
    )
}
