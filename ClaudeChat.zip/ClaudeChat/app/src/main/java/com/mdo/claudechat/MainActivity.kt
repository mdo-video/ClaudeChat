package com.mdo.claudechat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Tema sempre scuro: icone chiare nelle barre di sistema.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        val store = Store(applicationContext)
        setContent {
            var dynamic by remember { mutableStateOf(store.dynamic) }
            ClaudeTheme(dynamic) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    App(store, dynamic) {
                        dynamic = it
                        store.dynamic = it
                    }
                }
            }
        }
    }
}

@Composable
fun App(store: Store, dynamic: Boolean, onDynamic: (Boolean) -> Unit) {
    var screen by rememberSaveable { mutableStateOf("home") } // home | settings | chat:<id>
    val scope = rememberCoroutineScope()
    val session = remember { Session(store, scope) }
    val hasKey = remember(screen) { store.apiKey.isNotBlank() }

    // Controllo silenzioso all'avvio: se c'è una versione più nuova compare una scheda in Home.
    var update by remember { mutableStateOf<Updater.Info?>(null) }
    LaunchedEffect(Unit) {
        Updater.latest().onSuccess { if (it.versionCode > BuildConfig.VERSION_CODE) update = it }
    }

    BackHandler(enabled = screen != "home") { screen = "home" }

    val current = if (screen.startsWith("chat:")) session.chats.find { it.id == screen.removePrefix("chat:") } else null

    when {
        screen == "settings" -> SettingsScreen(store, dynamic, onDynamic) { screen = "home" }
        current != null -> ChatScreen(session, current) { screen = "home" }
        else -> HomeScreen(
            session = session,
            hasKey = hasKey,
            update = update,
            onOpen = { screen = "chat:${it.id}" },
            onNew = { screen = "chat:${session.newChat().id}" },
            onSettings = { screen = "settings" },
        )
    }
}
