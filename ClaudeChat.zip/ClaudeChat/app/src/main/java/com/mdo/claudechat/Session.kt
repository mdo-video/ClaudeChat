package com.mdo.claudechat

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Tiene chat, limiti e consumi, e invia i messaggi in un ambito che vive quanto l'app:
 * uscire da una chat mentre Claude risponde non fa perdere la risposta.
 */
class Session(private val store: Store, private val scope: CoroutineScope) {

    data class Live(val busy: Boolean = false, val status: String? = null, val error: String? = null)

    var chats by mutableStateOf(store.loadChats().sortedByDescending { it.updated })
        private set
    var limits by mutableStateOf(store.limits)
        private set
    var todayIn by mutableIntStateOf(store.todayUsage().first)
        private set
    var todayOut by mutableIntStateOf(store.todayUsage().second)
        private set
    var live by mutableStateOf<Map<String, Live>>(emptyMap())
        private set

    fun liveOf(id: String): Live = live[id] ?: Live()

    private fun setLive(id: String, value: Live) {
        live = live + (id to value)
    }

    private fun persist() {
        chats = chats.sortedByDescending { it.updated }
        store.saveChats(chats)
    }

    fun newChat(): Chat {
        val c = Chat(id = "c${System.currentTimeMillis()}", title = "Nuova chat", messages = emptyList(), updated = System.currentTimeMillis())
        chats = listOf(c) + chats
        persist()
        return c
    }

    fun delete(id: String) {
        chats = chats.filter { it.id != id }
        persist()
    }

    private fun append(id: String, msg: Msg) {
        chats = chats.map { c ->
            if (c.id != id) c
            else c.copy(
                title = if (c.messages.isEmpty() && msg.role == "user") msg.text.trim().lines().first().take(40) else c.title,
                messages = c.messages + msg,
                updated = System.currentTimeMillis(),
            )
        }
        persist()
    }

    private fun updateLimits(l: Limits?) {
        if (l == null || (l.reqLimit == null && l.tokLimit == null)) return
        limits = l
        store.limits = l
    }

    fun send(chatId: String, text: String) {
        val t = text.trim()
        if (t.isEmpty() || liveOf(chatId).busy) return
        append(chatId, Msg("user", t))
        setLive(chatId, Live(busy = true))
        scope.launch {
            var attempt = 0
            while (true) {
                val history = chats.firstOrNull { it.id == chatId }?.messages ?: break
                val result = ClaudeClient.ask(store.apiKey, store.model, history)
                val reply = result.getOrNull()
                if (reply != null) {
                    append(chatId, Msg("assistant", reply.text))
                    updateLimits(reply.limits)
                    val (i, o) = store.addUsage(reply.usage.input, reply.usage.output)
                    todayIn = i
                    todayOut = o
                    setLive(chatId, Live())
                    break
                }
                val e = result.exceptionOrNull()
                if (e is ClaudeClient.Retryable && attempt < 8) {
                    attempt++
                    updateLimits(e.limits)
                    var left = e.waitSeconds
                    while (left > 0) {
                        setLive(chatId, Live(busy = true, status = "Limite raggiunto: riprovo tra ${left}s. La chat resta qui."))
                        delay(1000)
                        left--
                    }
                    setLive(chatId, Live(busy = true))
                    continue
                }
                setLive(chatId, Live(error = e?.message ?: "Errore"))
                break
            }
        }
    }
}
