package com.mdo.claudechat

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Message
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.browser.customtabs.CustomTabsIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import org.json.JSONTokener

/**
 * Browser dentro l'app (WebView) pensato per usare i siti come vere app:
 * sessione salvata, allegati, microfono e fotocamera, popup di accesso, zoom e tastiera che ridimensiona la pagina.
 * Il tasto indietro del telefono chiude prima il popup, poi torna alla pagina precedente, poi chiude il browser.
 * L'icona con l'insetto mostra gli errori della pagina: utile se una pagina resta vuota.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(startUrl: String, title: String, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    var web by remember { mutableStateOf<WebView?>(null) }
    var popup by remember { mutableStateOf<WebView?>(null) }
    var progress by remember { mutableIntStateOf(0) }
    var pageTitle by remember { mutableStateOf(title) }
    var canBack by remember { mutableStateOf(false) }
    var chooser by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    var pendingPerm by remember { mutableStateOf<PermissionRequest?>(null) }
    var showLog by remember { mutableStateOf(false) }
    var compat by remember { mutableStateOf(false) }
    val log = remember { mutableStateListOf<String>() }

    fun addLog(line: String) {
        if (line.contains("Permissions-Policy")) return
        if (log.size >= 40) log.removeAt(0)
        log.add(line)
    }

    // Selettore file per gli allegati (foto, documenti) richiesti dalle pagine.
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        chooser?.onReceiveValue(uris.toTypedArray())
        chooser = null
    }

    // Permessi microfono e fotocamera richiesti dalla pagina (dettatura vocale, foto).
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val req = pendingPerm
        pendingPerm = null
        if (req != null) {
            val ok = req.resources.filter {
                it == PermissionRequest.RESOURCE_AUDIO_CAPTURE || it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
            }
            if (result.values.all { it } && ok.isNotEmpty()) req.grant(ok.toTypedArray()) else req.deny()
        }
    }

    fun closePopup() {
        popup?.destroy()
        popup = null
    }

    BackHandler {
        val p = popup
        when {
            p != null -> if (p.canGoBack()) p.goBack() else closePopup()
            canBack -> web?.goBack()
            else -> onClose()
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            CookieManager.getInstance().flush()
            popup?.destroy()
            web?.destroy()
        }
    }

    fun client(track: Boolean) = object : WebViewClient() {
        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            if (track) canBack = view.canGoBack()
        }

        override fun onPageFinished(view: WebView, url: String?) {
            if (track) canBack = view.canGoBack()
            CookieManager.getInstance().flush()
        }

        // Gli schemi web restano nell'app; mailto:, tel:, intent: ecc. passano alle app del telefono.
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val uri = request.url
            val scheme = uri.scheme ?: return false
            if (scheme in listOf("http", "https", "about", "data", "blob", "file", "javascript")) return false
            runCatching {
                context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            return true
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            addLog("RETE ${error.errorCode} ${error.description} ${request.url.host}${request.url.path}")
        }

        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
            if (errorResponse.statusCode >= 400) {
                addLog("HTTP ${errorResponse.statusCode} ${request.url.host}${request.url.path}")
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun baseSetup(wv: WebView) {
        wv.setBackgroundColor(0xFF141110.toInt())
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.javaScriptCanOpenWindowsAutomatically = true
        wv.settings.setSupportMultipleWindows(true)
        wv.settings.mediaPlaybackRequiresUserGesture = false
        wv.settings.useWideViewPort = true
        wv.settings.loadWithOverviewMode = true
        wv.settings.setSupportZoom(true)
        wv.settings.builtInZoomControls = true
        wv.settings.displayZoomControls = false
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
    }

    Scaffold(
        containerColor = cs.background,
        modifier = Modifier.imePadding(),
        topBar = {
            TopAppBar(
                title = { Text(pageTitle, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = { if (popup != null) closePopup() else onClose() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Chiudi")
                    }
                },
                actions = {
                    IconButton(onClick = { showLog = true }) { Icon(Icons.Filled.BugReport, "Diagnostica") }
                    IconButton(onClick = { web?.reload() }) { Icon(Icons.Filled.Refresh, "Ricarica") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (progress in 1..99) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier.fillMaxWidth(),
                    color = cs.primary,
                    trackColor = cs.surfaceContainerHighest,
                )
            }
            Box(Modifier.fillMaxSize()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            baseSetup(this)
                            webViewClient = client(true)
                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView, newProgress: Int) {
                                    progress = newProgress
                                }

                                override fun onReceivedTitle(view: WebView, t: String?) {
                                    if (!t.isNullOrBlank()) pageTitle = t
                                }

                                override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                                    val level = m.messageLevel()
                                    if (level == ConsoleMessage.MessageLevel.ERROR || level == ConsoleMessage.MessageLevel.WARNING) {
                                        addLog("JS $level ${m.message()} (${m.sourceId().orEmpty().substringAfterLast('/')}:${m.lineNumber()})")
                                    }
                                    return true
                                }

                                override fun onShowFileChooser(
                                    webView: WebView,
                                    callback: ValueCallback<Array<Uri>>,
                                    params: FileChooserParams,
                                ): Boolean {
                                    chooser?.onReceiveValue(null)
                                    chooser = callback
                                    picker.launch("*/*")
                                    return true
                                }

                                override fun onPermissionRequest(request: PermissionRequest) {
                                    val needed = mutableListOf<String>()
                                    request.resources.forEach {
                                        if (it == PermissionRequest.RESOURCE_AUDIO_CAPTURE) needed += Manifest.permission.RECORD_AUDIO
                                        if (it == PermissionRequest.RESOURCE_VIDEO_CAPTURE) needed += Manifest.permission.CAMERA
                                    }
                                    val missing = needed.filter {
                                        ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
                                    }
                                    if (needed.isEmpty()) {
                                        request.deny()
                                    } else if (missing.isEmpty()) {
                                        request.grant(
                                            request.resources.filter {
                                                it == PermissionRequest.RESOURCE_AUDIO_CAPTURE ||
                                                    it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
                                            }.toTypedArray(),
                                        )
                                    } else {
                                        pendingPerm = request
                                        permLauncher.launch(missing.toTypedArray())
                                    }
                                }

                                // Popup di accesso: va aperta in una WebView vera, collegata alla pagina che l'ha aperta.
                                override fun onCreateWindow(
                                    view: WebView,
                                    isDialog: Boolean,
                                    isUserGesture: Boolean,
                                    resultMsg: Message,
                                ): Boolean {
                                    val child = WebView(view.context)
                                    baseSetup(child)
                                    child.webViewClient = client(false)
                                    child.webChromeClient = object : WebChromeClient() {
                                        override fun onCloseWindow(window: WebView) {
                                            if (popup === window) popup = null
                                            window.destroy()
                                        }
                                    }
                                    popup?.destroy()
                                    popup = child
                                    val transport = resultMsg.obj as WebView.WebViewTransport
                                    transport.webView = child
                                    resultMsg.sendToTarget()
                                    return true
                                }
                            }
                            loadUrl(startUrl)
                        }.also { web = it }
                    },
                )
                popup?.let { p ->
                    key(p) { AndroidView(modifier = Modifier.fillMaxSize(), factory = { p }) }
                }
            }
        }
    }

    if (showLog) {
        AlertDialog(
            onDismissRequest = { showLog = false },
            title = { Text("Diagnostica pagina") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    SelectionContainer {
                        Text(log.reversed().joinToString("\n").ifBlank { "Nessun errore registrato." }, fontSize = 11.sp)
                    }
                    TextButton(onClick = {
                        compat = !compat
                        web?.setLayerType(if (compat) View.LAYER_TYPE_SOFTWARE else View.LAYER_TYPE_NONE, null)
                        web?.reload()
                    }) { Text(if (compat) "Modalità compatibile: attiva (tocca per disattivare)" else "Prova modalità compatibile") }
                    TextButton(onClick = {
                        val url = web?.url ?: startUrl
                        CustomTabsIntent.Builder().build().launchUrl(context, Uri.parse(url))
                    }) { Text("Apri questa pagina in Chrome") }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    web?.evaluateJavascript(PROBE) { raw ->
                        val txt = runCatching { JSONTokener(raw).nextValue().toString() }.getOrDefault(raw ?: "")
                        addLog("ANALISI $txt")
                    }
                }) { Text("Analizza pagina") }
            },
            dismissButton = { TextButton(onClick = { showLog = false }) { Text("Chiudi") } },
        )
    }
}

// Misure della pagina: dove si trova davvero il testo della schermata iniziale (posizione, trasformazioni, zoom).
private const val PROBE = "(function(){try{var o={};var vv=window.visualViewport;" +
    "o.vv=vv?[vv.offsetLeft,vv.offsetTop,vv.pageLeft,vv.pageTop,vv.scale,vv.width,vv.height].map(function(x){return Math.round(x*100)/100}):'n/a';" +
    "var se=document.scrollingElement;o.scroll=[scrollX,scrollY,se.scrollWidth,se.scrollHeight];" +
    "function R(e){var r=e.getBoundingClientRect();return Math.round(r.left)+','+Math.round(r.top)+' '+Math.round(r.width)+'x'+Math.round(r.height)}" +
    "var b=document.body;o.body=R(b);" +
    "var w=document.createTreeWalker(b,NodeFilter.SHOW_TEXT);var t;var el=null;" +
    "while(t=w.nextNode()){if(t.nodeValue.indexOf('aiutarti')>-1){el=t.parentElement;break}}" +
    "if(el){var ch=[];var n=el;var i=0;" +
    "while(n&&n!==document.documentElement&&i<8){var c=getComputedStyle(n);" +
    "ch.push(n.tagName.toLowerCase()+' '+R(n)+' tf:'+c.transform+' ov:'+c.overflow+' op:'+c.opacity+' d:'+c.display);n=n.parentElement;i++}" +
    "o.text=ch}else{o.text='non trovato'}" +
    "return JSON.stringify(o)}catch(err){return 'errore '+err}})()"
