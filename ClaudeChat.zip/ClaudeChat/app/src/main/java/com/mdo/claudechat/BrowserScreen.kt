package com.mdo.claudechat

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.Uri
import android.os.Message
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.viewinterop.AndroidView

/**
 * Browser dentro l'app (WebView). Sessione e cookie restano salvati tra un'apertura e l'altra.
 * Il tasto indietro del telefono torna alla pagina precedente; a fine cronologia chiude il browser.
 */
@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(startUrl: String, title: String, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var web by remember { mutableStateOf<WebView?>(null) }
    var progress by remember { mutableIntStateOf(0) }
    var pageTitle by remember { mutableStateOf(title) }
    var canBack by remember { mutableStateOf(false) }
    var chooser by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    // Finestra popup (serve all'accesso con Google, che risponde alla pagina tramite window.opener).
    var popup by remember { mutableStateOf<WebView?>(null) }

    // Selettore file per gli allegati (foto, documenti) richiesti dalle pagine.
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        chooser?.onReceiveValue(uris.toTypedArray())
        chooser = null
    }

    BackHandler {
        val p = popup
        when {
            p != null -> if (p.canGoBack()) p.goBack() else { p.destroy(); popup = null }
            canBack -> web?.goBack()
            else -> onClose()
        }
    }

    fun client(track: Boolean) = object : WebViewClient() {
        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            if (track) canBack = view.canGoBack()
        }

        override fun onPageFinished(view: WebView, url: String?) {
            if (track) canBack = view.canGoBack()
            CookieManager.getInstance().flush()
        }

        // Resta nell'app per i siti web; ignora schemi strani (intent:, mailto:...).
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val u = request.url.toString()
            return !(u.startsWith("http://") || u.startsWith("https://"))
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun baseSetup(wv: WebView) {
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.javaScriptCanOpenWindowsAutomatically = true
        wv.settings.setSupportMultipleWindows(true)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
    }
    DisposableEffect(Unit) {
        onDispose {
            CookieManager.getInstance().flush()
            popup?.destroy()
            web?.destroy()
        }
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text(pageTitle, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Chiudi") }
                },
                actions = {
                    IconButton(onClick = { web?.reload() }) { Icon(Icons.Filled.Refresh, "Ricarica") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (progress in 1..99) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier.fillMaxWidth(),
                    color = cs.primary,
                    trackColor = cs.surfaceContainerHighest,
                )
            }
            Box(Modifier.fillMaxSize()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            baseSetup(this)
                            webViewClient = client(true)
                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView, newProgress: Int) {
                                    progress = newProgress
                                }

                                override fun onReceivedTitle(view: WebView, t: String?) {
                                    if (!t.isNullOrBlank()) pageTitle = t
                                }

                                override fun onShowFileChooser(
                                    webView: WebView,
                                    callback: ValueCallback<Array<Uri>>,
                                    params: FileChooserParams,
                                ): Boolean {
                                    chooser?.onReceiveValue(null)
                                    chooser = callback
                                    picker.launch("*/*")
                                    return true
                                }

                                // Popup di accesso: va aperta in una WebView vera, collegata alla pagina che l'ha aperta.
                                override fun onCreateWindow(
                                    view: WebView,
                                    isDialog: Boolean,
                                    isUserGesture: Boolean,
                                    resultMsg: Message,
                                ): Boolean {
                                    val child = WebView(view.context)
                                    baseSetup(child)
                                    child.webViewClient = client(false)
                                    child.webChromeClient = object : WebChromeClient() {
                                        override fun onCloseWindow(window: WebView) {
                                            if (popup === window) popup = null
                                            window.destroy()
                                        }
                                    }
                                    popup?.destroy()
                                    popup = child
                                    val transport = resultMsg.obj as WebView.WebViewTransport
                                    transport.webView = child
                                    resultMsg.sendToTarget()
                                    return true
                                }
                            }
                            loadUrl(startUrl)
                        }.also { web = it }
                    },
                )
                popup?.let { p ->
                    key(p) { AndroidView(modifier = Modifier.fillMaxSize(), factory = { p }) }
                }
            }
        }
    }
}
