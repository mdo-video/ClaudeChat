package com.mdo.claudechat

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate

/**
 * La chiave API è salvata cifrata sul dispositivo (EncryptedSharedPreferences).
 * Le chat restano in locale in un file JSON: è questo che permette di non perdere mai la conversazione.
 */
class Store(context: Context) {

    private val secure: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "claudechat_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )
    private val plain: SharedPreferences =
        context.getSharedPreferences("claudechat_plain", Context.MODE_PRIVATE)
    private val chatsFile = File(context.filesDir, "chats.json")

    var apiKey: String
        get() = secure.getString("api_key", "") ?: ""
        set(value) = secure.edit().putString("api_key", value.trim()).apply()

    var model: String
        get() = plain.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(value) = plain.edit().putString("model", value.trim().ifBlank { DEFAULT_MODEL }).apply()

    /** Colori dinamici (Material You), solo Android 12 o più recente. */
    var dynamic: Boolean
        get() = plain.getBoolean("dynamic", false)
        set(value) = plain.edit().putBoolean("dynamic", value).apply()

    var limits: Limits?
        get() = Limits.fromJson(plain.getString("limits", null))
        set(value) = plain.edit().putString("limits", value?.toJson()).apply()

    /** Token consumati oggi (ingresso, uscita). Si azzerano da soli al cambio di giorno. */
    fun todayUsage(): Pair<Int, Int> {
        if (plain.getString("u_day", "") != LocalDate.now().toString()) return 0 to 0
        return plain.getInt("u_in", 0) to plain.getInt("u_out", 0)
    }

    fun addUsage(input: Int, output: Int): Pair<Int, Int> {
        val (i, o) = todayUsage()
        plain.edit()
            .putString("u_day", LocalDate.now().toString())
            .putInt("u_in", i + input)
            .putInt("u_out", o + output)
            .apply()
        return (i + input) to (o + output)
    }

    fun loadChats(): List<Chat> = runCatching {
        if (!chatsFile.exists()) return emptyList()
        val arr = JSONArray(chatsFile.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val ms = o.getJSONArray("messages")
            Chat(
                id = o.getString("id"),
                title = o.getString("title"),
                updated = o.optLong("updated"),
                messages = (0 until ms.length()).map { j ->
                    val m = ms.getJSONObject(j)
                    Msg(m.getString("role"), m.getString("text"))
                },
            )
        }
    }.getOrDefault(emptyList())

    fun saveChats(list: List<Chat>) {
        val arr = JSONArray()
        list.forEach { c ->
            val ms = JSONArray()
            c.messages.forEach { ms.put(JSONObject().put("role", it.role).put("text", it.text)) }
            arr.put(
                JSONObject().put("id", c.id).put("title", c.title).put("updated", c.updated).put("messages", ms),
            )
        }
        runCatching { chatsFile.writeText(arr.toString()) }
    }

    companion object {
        // Modello predefinito: si può cambiare dalle Impostazioni se Anthropic lo sostituisce.
        const val DEFAULT_MODEL = "claude-sonnet-5-5"
    }
}
