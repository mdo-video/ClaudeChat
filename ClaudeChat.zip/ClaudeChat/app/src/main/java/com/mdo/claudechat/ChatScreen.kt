package com.mdo.claudechat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(session: Session, chat: Chat, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val live = session.liveOf(chat.id)
    var input by remember(chat.id) { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Scorri in fondo quando arriva un messaggio o cambia lo stato.
    LaunchedEffect(chat.messages.size, live.busy) {
        val extra = if (live.busy || live.error != null) 1 else 0
        val count = chat.messages.size + extra
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    Scaffold(
        containerColor = cs.background,
        modifier = Modifier.imePadding(),
        topBar = {
            TopAppBar(
                title = { Text(chat.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Indietro") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
        bottomBar = {
            Row(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    placeholder = { Text("Scrivi a Claude") },
                    maxLines = 5,
                )
                IconButton(
                    enabled = input.isNotBlank() && !live.busy,
                    onClick = {
                        session.send(chat.id, input)
                        input = ""
                    },
                ) { Icon(Icons.AutoMirrored.Filled.Send, "Invia", tint = cs.primary) }
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Box(Modifier.padding(horizontal = 12.dp)) {
                UsageCard(session.limits, session.todayIn, session.todayOut, compact = true)
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(chat.messages) { m -> Bubble(m, context) }
                if (live.busy) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CircularProgressIndicator(Modifier.padding(4.dp), strokeWidth = 2.dp)
                            Text(
                                live.status ?: "Claude sta scrivendo...",
                                color = cs.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
                live.error?.let { err ->
                    item { Text(err, color = cs.error, style = MaterialTheme.typography.bodyMedium) }
                }
            }
        }
    }
}

@Composable
private fun Bubble(m: Msg, context: Context) {
    val cs = MaterialTheme.colorScheme
    val mine = m.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier
                .widthIn(max = 320.dp)
                .background(if (mine) cs.primaryContainer else cs.surfaceContainerHigh, RoundedCornerShape(20.dp))
                .padding(14.dp),
        ) {
            Text(
                if (mine) androidx.compose.ui.text.AnnotatedString(m.text) else renderMarkdown(m.text, cs.primary),
                color = if (mine) cs.onPrimaryContainer else cs.onSurface,
            )
            if (!mine) {
                IconButton(
                    onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("Claude", plainText(m.text)))
                    },
                    modifier = Modifier.align(Alignment.End).padding(top = 2.dp),
                ) { Icon(Icons.Filled.ContentCopy, "Copia", Modifier.padding(2.dp), tint = cs.onSurfaceVariant) }
            }
        }
    }
}
